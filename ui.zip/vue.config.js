module.exports = {
  "runtimeCompiler": true,
  "transpileDependencies": [
    "vuetify"
  ]
}