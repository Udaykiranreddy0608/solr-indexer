<template>
  <div class="home xs:-mt-10 sm:-mt-10 md:-mt-10 lg:-mt-10">
    <SearchBox />
    <SearchResults :results="results" />
  </div>
</template>

<script>
// @ is an alias to /src
import { mapState } from 'vuex'
import SearchBox from '@/components/home/SearchBox'
import SearchResults from '@/components/home/SearchResults'
export default {
  name: 'Home',
  components: {
    SearchBox,
    SearchResults
  },
  computed: {
    ...mapState ({
      results: state => state.search.searchResults
    })
  },
}
</script>

<style>
</style>
