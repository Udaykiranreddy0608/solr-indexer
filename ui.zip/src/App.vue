<template>
  <v-app>
    <Header />
    <v-main>
      <router-view />
    </v-main>
    <Footer />
  </v-app>
</template>

<script>
import Header from '@/components/layout/Header'
import Footer from '@/components/layout/Footer'
export default {
  name: 'App',
  components: {
    Header,
    Footer
  },  
  data: () => ({
    //
  }),
};
</script>

<style>
</style>
