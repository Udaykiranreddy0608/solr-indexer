/* eslint-disable no-unused-vars */
import axios from 'axios'

// initial state
const state = {
  searchResults: []
}

// getters
const getters = {}

// actions
const actions = {
  async getSearchResults ({commit}, payload) {
    try {
      let result = await axios.post('http://3.134.243.88:8080/newton/v1/getcustom', payload)
      commit('SET_SEARCH_RESULTS', result.data)
    } catch (e) {
      commit('SET_SEARCH_RESULTS', [])
    }
  }
}

// mutations
const mutations = {
  SET_SEARCH_RESULTS (state, results) {
    state.searchResults = results
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}