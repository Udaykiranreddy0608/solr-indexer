<template>
  <div class="">
    <!-- #0D2461 -->
    <v-app-bar app color="white" light height="90px">
      <!-- <v-app-bar-nav-icon @click="drawer = true"></v-app-bar-nav-icon> -->
      <img src="img/logos/logo.jpeg" alt="Masorixt" class="h-20" />
    </v-app-bar>
  </div>
</template>

<script>
// import VerticalContent from '@/components/content/Vertical'
// import DefaultContent from '@/components/content/Default'
// import MobileContent from '@/components/content/MobileContent'
/* eslint-disable no-console */
export default {
  name: "Header",
  components: {
    // VerticalContent,
    // DefaultContent,
    // MobileContent
  },
  data() {
    return {};
  },
  methods: {},
};
</script>

<style lang="scss" scoped>
.v-application ul,
.v-application ol {
  padding-left: 0 !important;
}
header {
  box-shadow: 0 2px 30px -1px rgba(85, 85, 85, 0.08),
    0 4px 30px 0 rgba(85, 85, 85, 0.06), 0 1px 30px 0 rgba(85, 85, 85, 0.03) !important;
}
</style>