<template>
  <div class="max-w-7xl mx-auto px-4">
    <span class="text-gray-600 text-lg" v-if = "results.totalElements != null">Total documents found : <strong>{{results.totalElements}}</strong></span>
    <v-card
      class="mx-auto my-4 p-4"
      v-for="(result, index) in results.content"
      :key="index"
    >
      <div class="flex flex-col">
        <div>
          <span class="inline"><strong>Title:</strong> {{result.title === null ? 'No title' : result.title}}</span>
        </div>       
        <span><strong>Subject:</strong> {{result.subject ===  null ? 'No Subject' : result.subject}}</span>
        <span><strong>Author:</strong> {{result.author === null ? 'No Author' : result.author}}</span>
        <span><strong>File name:</strong> {{result.fileName === null ? 'No file name' : result.fileName}}</span>
        <span><strong>Format:</strong> {{result.format}}</span>
        <span><strong>Creation Date:</strong> {{result.creationDate}}</span>
        <span><strong>Modified Date:</strong> {{result.modifiedDate}}</span>
        <span><strong>Creator Tool:</strong> {{result.creatorTool}}</span>
        <span><v-dialog
        v-model="showContent"
        width="600px"
      >
        <template v-slot:activator="{ on, attrs }">
          <v-btn color="green" dark @click="showContentDialog(index)" v-bind="attrs" v-on="on" small class="mt-2 w-40 text-white px-4 inline text-white"><v-icon color="white">mdi-alert-circle</v-icon> View Content</v-btn>
        </template>
          <v-card>
          <v-card-title>
            <span class="headline">Content</span>
          </v-card-title>
          <v-card-text>
            {{results.content[currentIndex].content}}
          </v-card-text>
          </v-card>
          </v-dialog> </span>
      </div>     
    </v-card>
  </div>
</template>

<script>
  export default {
    name: 'SearchResults',
    props: ['results'],
    data () {
      return {
        showContent: false,
        currentIndex: 0
      }
    },
    methods: {
      showContentDialog (index) {
        this.currentIndex = index
      }
    }
  }
</script>

<style lang="scss" scoped>

</style>

// author: null
// content: "  Journal of Alzheimer’s Disease 62 (2018) 1443–14"
// creationDate: "Tue Mar 13 11:10:32 UTC 2018"
// creatorTool: "DVIPSONE 2.2.2  http://www.YandY.com"
// documentID: null
// encrypted: "false"
// fileName: "/home/ec2-user/files/nishad_files/jad-62-jad171119.pdf"
// format: "application/pdf; version=1.4"
// id: "9960c93c-c901-4e09-b6c5-7fc56fe2a0f6"
// modifiedDate: "Tue Mar 13 11:10:32 UTC 2018"
// subject: null
// title: null