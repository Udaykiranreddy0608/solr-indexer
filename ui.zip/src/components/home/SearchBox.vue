<template>
  <div>
    <v-col
      cols="6"
      sm="6"
      class="mx-auto mt-16 flex flex-row"
    >
      <v-text-field
        v-model="searchTerm"
        solo
        label="Search here"
        clearable        
        :loading="loader"
        class="mx-auto"
        append-icon="mdi-magnify"
        @click:append="search"
      ></v-text-field>
    </v-col>
  </div>
</template>

<script>
  import { mapActions } from 'vuex'
  export default {
    name: 'SearchBox',
    data () {
      return {
        searchTerm: '',
        loader: false
      }
    },    
    methods: {
      ...mapActions({
        getSearchResults: 'search/getSearchResults'
      }),
      search () {
        this.loader = true
        this.getSearchResults({ 'searchTerm': this.searchTerm })
          .then(() => {
            this.loader = false
          })
      }
    }
  }
</script>

<style lang="scss" scoped>

</style>
